<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/9bacefac-4425-4350-8555-6876ceaba219

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Copy [.env.example](.env.example) to `.env.local` and add any API keys you want to enable:
   - `RAWG_API_KEY` enables `/api/rawg`
   - `TWITCH_CLIENT_ID` and `TWITCH_CLIENT_SECRET` enable `/api/igdb`
   - `GEMINI_API_KEY` is available for AI Studio features
   - Optional quota guards: `IGDB_REQUEST_INTERVAL_MS=300`, `RAWG_MONTHLY_LIMIT=20000`, `RAWG_REQUEST_INTERVAL_MS=1500`
3. Run the app:
   `npm run dev`
